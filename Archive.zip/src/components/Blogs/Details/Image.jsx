import React from 'react';

function Image() {
  return (
    <div className="img">
      <img src="/img/blog/single.jpg" alt="" />
    </div>
  )
}

export default Image