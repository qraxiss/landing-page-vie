const WOW = window.WOW;
new WOW().init();